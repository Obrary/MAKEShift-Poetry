Product: MAKEShift Poetry, November 2014

Designer: High Tech High, San Diego

Support:  http://forums.obrary.com/category/designs/makeshift-poetry

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design
